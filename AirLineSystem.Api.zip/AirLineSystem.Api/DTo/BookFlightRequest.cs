﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirLineSystem.Api.DTo
{
    public class BookFlightRequest
    {
        public decimal Amount { get; set; }
    }
}
