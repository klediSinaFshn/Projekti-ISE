using AirLineSystem.Api.DTo;
using AirLineSystem.Domain.Models;
using AirLineSystem.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AirLineSystem.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BookingController : ControllerBase
    {


        private readonly ILogger<BookingController> _logger;

        private readonly IBookingService _bookingService;

        private readonly IPaymentProcess _paymentProcess;

        public BookingController(ILogger<BookingController> logger, IBookingService bookingService, IPaymentProcess paymentProcess)
        {
            _logger = logger;
            _bookingService = bookingService;
            _paymentProcess = paymentProcess;


        }

        [HttpGet("search")]
        public async Task<IActionResult> SearchFlights(string departure,
                                                       string destination, DateTime date)
        {
            var flights = await _bookingService.SearchFlights(departure, destination, date);
            return Ok(flights);
        }

        [HttpPost("book")]
        //[Authorize]
        public async Task<IActionResult> BookFlight(BookFlightRequest request)
        {
            if (request.Amount <= 0)
            {
                return BadRequest("Invalid flight amount");
            }

            // Call CreateOrderAsync and pass the request amount
            try
            {
                var response = await _paymentProcess.CreateOrderAsync(request.Amount);
                return Ok(new { response });
            }
            catch (Exception ex) { 
                return BadRequest(ex.Message);
            }
            // Return a success response after payment
            
        }

        

        [HttpDelete("cancel/{ticketNumber}")]
        [Authorize]
        public async Task<IActionResult> CancelBooking(string ticketNumber) 
        {
            await _bookingService.CancelBooking(ticketNumber);
            return Ok("Booking canceled successfully");
        }
      
    }
}
